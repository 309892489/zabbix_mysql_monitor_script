#!/bin/bash

case $1 in

status)
  /usr/local/script/mysql_status.sh $2 $3
  ;;

cpu_used)
  /usr/local/script/port_cpu_used.sh $2
  ;;

mem_used)
  /usr/local/script/port_mem_used.sh $2
  ;;

logerr)
  /usr/local/script/mysql_monitor_logerr.sh $2
  ;;

variables)
  /home/mysql/mysql$3/bin/mysql --defaults-extra-file=/home/mysql/mysql$3/etc/root.cnf -BNe "show global variables like '$2'\G" 2>/dev/null |tail -1
  ;;

version)
  /home/mysql/mysql$2/bin/mysql --defaults-extra-file=/home/mysql/mysql$2/etc/root.cnf -BNe "select version()"
  ;;

esac
