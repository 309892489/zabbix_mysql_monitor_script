port=$1

pid=`ps aux|grep mysqld|grep ${port}|grep -v mysqld_safe|awk '{print $2}'`;mymem=`cat /proc/$pid/status |grep VmRSS|awk -F" " '{print $2}'`;totalmem=`cat /proc/meminfo |grep MemTotal|awk -F" " '{print $2}'`;echo `awk 'BEGIN{printf "%.3f", 100*('$mymem' / '$totalmem')}'`
