#!/bin/sh
param=$1
port=$2
mysql=/home/mysql/mysql${port}
extra_file=/home/mysql/mysql${port}/etc/root.cnf

case $param in 

Seconds_Behind_Master)
      result=` ${mysql}/bin/mysql  --defaults-extra-file=${extra_file} -e "show slave status\G" 2>/dev/null | grep -w Seconds_Behind_Master|awk -F':' '{print $2}' | grep -v "Using a password" `
        if [[ -z $result ]]; then
                echo 0
        else
                echo $result
        fi
        ;;

Data_incr)
      result=`${mysql}/bin/mysql  --defaults-extra-file=${extra_file} -BNe "select sum(data_length)+sum(index_length) from information_schema.tables;" 2>/dev/null |tail -1`
      echo $result
      ;;

IOPS)
      result=`${mysql}/bin/mysql  --defaults-extra-file=${extra_file}  -BNe "select (select 2*sum(VARIABLE_VALUE) from performance_schema.global_status where variable_name in ('Key_writes','Key_reads')) + (select sum(VARIABLE_VALUE) from performance_schema.global_status where variable_name in ('Innodb_data_writes','Innodb_data_reads','Innodb_dblwr_writes','Innodb_log_writes','Key_read_requests')) IO;" 2>/dev/null |tail -1`
      echo $result
      ;;

Table_lock)
      lock_table_num=` ${mysql}/bin/mysql  --defaults-extra-file=${extra_file}  -e "show open tables where In_use > 0" 2>/dev/null |wc -l `
      if [ $lock_table_num -eq 0  ]; then
             result=0
      else
             result=1
      fi
             echo $result
      ;;

Slave_SQL)
      result=`${mysql}/bin/mysql --defaults-extra-file=${extra_file}   -e "show slave status\G" 2>/dev/null|grep Slave_SQL_Running|grep Yes|wc -l`
      echo $result
      ;;

Slave_IO)
      result=`${mysql}/bin/mysql --defaults-extra-file=${extra_file}   -e "show slave status\G" 2>/dev/null|grep Slave_IO_Running|grep Yes|wc -l`
      echo $result
      ;;

*)
      result=`${mysql}/bin/mysqladmin --defaults-extra-file=${extra_file}   extended-status 2>/dev/null | grep -w ${param} |cut -d "|" -f3`
echo $result
;;

esac
