#!/bin/sh
monitor()
{
if [ $CONTS -gt 0 ]; then

egrep -i "ERROR|Warning|mysqld_safe|deadlock" $ERR_LOG | grep -v "Aborted connection" | grep -v "Start binlog_dump" | grep -v "'proxies_priv'" | grep -v "'user' entry" | grep -v "Failed to allocate" | grep -v "Using conventional memory" | grep -v "Event Scheduler:" | grep -v "was not purged because" | grep -v "Unsafe statement" |grep -v "Timeout waiting for reply of binlog"> /dev/null
ALLError=$?

egrep -i "Aborted connection" $ERR_LOG | egrep "error reading communication" > /dev/null 2>&1
AC=$?

AbortIP=`egrep -i "Aborted connection" $ERR_LOG | egrep "error reading communication" | egrep -o "[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}" | sort | uniq | awk -v RS= 'NR==1{for(i=1;i<=NF;i++) ipstr = ipstr "," $i ; print ipstr}'`

if [ $AC = 0 ]; then
	echo "content=$NOW $MYSQLIP AbortedIP$AbortIP" 

fi

if [ $ALLError = 0 ]; then
egrep "ERROR|Warning|mysqld_safe|deadlock" $ERR_LOG | grep -v "Aborted connection" | grep -v "Start binlog_dump" | grep -v "'proxies_priv'" | grep -v "'user' entry" | grep -v "Failed to allocate" | grep -v "Using conventional memory" | grep -v "Event Scheduler:" | grep -v "was not purged because" | grep -v "Unsafe statement" |grep -v "Timeout waiting for reply of binlog"| sort | uniq |
	while read line;
		do
			echo "$line" 
		done
else
	echo "Errorlog file is ok."

fi
cat $ERR_LOG >> $ERR_LOG_ARC && > $ERR_LOG
else
	echo "Errorlog file is ok."
fi
}


port=$1
mysql=/home/mysql/mysql${port}
extra_file=/home/mysql/mysql${port}/etc/root.cnf


${mysql}/bin/mysqladmin --defaults-extra-file=${extra_file} ping >/dev/null 2>&1
if [ $? -ne 0 ];then
        echo "Warning,mysql not connect,please check log!"
        echo "`date +%D-%H:%M:%S` port:$port login_path:`ps -ef|grep mysqld|grep socket |grep -v grep|tail -1`">>/opt/zabbix/logs/mysql_login_path.log
        exit
fi


ERR_LOG=`${mysql}/bin/mysql  --defaults-extra-file=${extra_file} -e "show variables like 'log_error%';" 2>/dev/null | grep -w log_error | awk -F' ' '{print $2}' | grep -v "Using a password"`
ERR_DIR=`dirname ${ERR_LOG}`
ERR_LOG_ARC=${ERR_LOG}.arc
MYSQLIP=MYSQL-$port
declare -i CONTS=`cat $ERR_LOG | wc -l`
DATE=`date "+%F%T"`
NOW=`date '+%Y%m%d %k:%M'`

monitor $CONTS $port $ERR_LOG $ERR_LOG_ARC $MYSQLIP $DATE $NOW

